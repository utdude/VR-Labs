# VIRTUAL-REALITY-LABORATORY

1. 3d models
2. setup in gaming engine
3. functional backend
4. export
